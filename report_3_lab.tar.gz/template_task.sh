#!/bin/bash

SCRIPT_NAME=$(basename "$0")
FIFO="/tmp/run/cuckoo.pid"
LOG_FILE="report_${SCRIPT_NAME}.log"
PID=$$

if [ "$SCRIPT_NAME" == "template_task.sh" ]; then
    echo "я бригадир, сам не работаю"
        exit 0
        fi

        echo "$(date '+%Y-%m-%d %H:%M:%S') [$PID] Скрипт запущен" >> "$LOG_FILE"

        echo "${SCRIPT_NAME%.sh}[$PID]: how much time do I have?" > "$FIFO"

        sleep 1
        N=$(grep "${SCRIPT_NAME%.sh}\[$PID\]" cuckoo.log | tail -n 1 | awk '{print $NF}')

        if [ -n "$N" ]; then
            sleep "$N"
                echo "$(date '+%Y-%m-%d %H:%M:%S') [$PID] Скрипт завершился, работал $N секунд." >> "$LOG_FILE"
                fi

