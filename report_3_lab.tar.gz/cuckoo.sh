#!/bin/bash

mkdir -p /tmp/run
[[ -p /tmp/run/cuckoo.pid ]] || mkfifo /tmp/run/cuckoo.pid

cleanup() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') Shutdown!" >> cuckoo.log
        rm -f /tmp/run/cuckoo.pid
            exit 0
            }

            trap cleanup SIGTERM SIGINT

	    echo "$(date '+%Y-%m-%d %H:%M:%S') Startup!" >> cuckoo.log

            while true; do
                if read line < /tmp/run/cuckoo.pid; then
                        if [[ "$line" =~ ^(.*\[[0-9]+\]):\ how\ much\ time\ do\ I\ have\? ]]; then
                                    NAME_PID="${BASH_REMATCH[1]}"
                                                N=$(( RANDOM % 9 + 2 ))
                                                            echo "$(date '+%Y-%m-%d %H:%M:%S') $NAME_PID $N" >> cuckoo.log
                                                                    fi
                                                                        fi
                                                                        done

