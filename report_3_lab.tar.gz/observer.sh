#!/bin/bash

CONFIG="observer.conf"
LOG="observer.log"

if [ ! -f "$CONFIG" ]; then
    exit 1
    fi

    while IFS= read -r script_name || [ -n "$script_name" ]; do
        [ -z "$script_name" ] && continue

            if ! pgrep -f "$script_name" > /dev/null; then
                    if [ -f "./$script_name" ]; then
                                nohup ./$script_name > /dev/null 2>&1 &
                                            echo "$(date '+%Y-%m-%d %H:%M:%S') $script_name Restarted PID $!" >> "$LOG"
                                                    fi
                                                        fi
                                                        done < "$CONFIG"

